const dataStatus = {
  initial: "Начальный",
  in_progress: "В процессе",
  paused: "На паузе",
  completed: "Завершен",
  canceled: "Отменен",
};

export default dataStatus;
